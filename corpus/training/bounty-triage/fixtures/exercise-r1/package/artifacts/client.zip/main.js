const { app } = require("electron");
const API_BASE = "https://api.example.test/v1";
app.whenReady().then(() => {
  console.log("ready", API_BASE);
});
