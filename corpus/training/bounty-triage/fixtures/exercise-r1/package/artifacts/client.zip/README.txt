Authored training fixture for the bounty-triage module.
All host names use the reserved .test TLD; nothing here is live.
