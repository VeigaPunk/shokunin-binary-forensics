# note
authored fixture content
